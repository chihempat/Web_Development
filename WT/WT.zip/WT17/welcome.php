<?php 
	echo "Welcome:  " .$_POST["name"];
	echo "<BR>";
 	echo "Your email address is:  " .$_POST["email"]; 
	echo "<BR>";
	echo "Enrollment_no:  " .$_POST["enroll"];
	echo "<BR>";
 	echo "Year:  " .$_POST["year"]; 
	echo "<BR>";
	echo "Semester:  " .$_POST["sem"]; 
	echo "<BR>";
	echo "Branch:  " .$_POST["branch"]; 
	echo "<BR>";
	echo "Year of Admission:  " .$_POST["yoa"]; 
	echo "<BR>";
	
?>